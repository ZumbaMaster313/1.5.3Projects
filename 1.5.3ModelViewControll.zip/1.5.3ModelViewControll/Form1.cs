﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ImageProcessor;
using System.IO;
using System.Drawing.Imaging;



namespace _1._5._3ModelViewControll
{
    public partial class Window : Form
    {

        public float speed = 1;

        public Window()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void MoveBar_Scroll(object sender, EventArgs e)
        {
            MoveBar.Maximum = 235;
            MoveBar.Minimum = 35;
            TextBox.Text = "" + MoveBar.Value;

            int x = PictureBox.Location.X;
            int y = PictureBox.Location.Y;

            y = 1;
            y *= MoveBar.Value;

            PictureBox.Location = new Point(x, y);

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PictureBox_Click(object sender, EventArgs e)
        {
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
           trackBar1.Maximum = 255;
           trackBar1.Minimum = 0;
           textBox2.Text = trackBar1.Value.ToString();

            Color myColor = Color.FromArgb(trackBar1.Value, 128, 128);

            string hex = "#" + myColor.R.ToString("X2") + myColor.G.ToString("X2") + myColor.B.ToString("X2");  

            PictureBox.BackColor = ColorTranslator.FromHtml(hex);



        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
